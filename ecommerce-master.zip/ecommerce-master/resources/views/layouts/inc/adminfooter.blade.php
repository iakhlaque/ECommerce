<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="https://www.linkedin.com/in/george-derderian-a34516219/">
                        About Me
                    </a>
                </li>
                <li>
                    <a href="https://github.com/derderian7">
                        Github
                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright float-right" id="date">
            made with <i class="material-icons">favorite</i> by
            <a href="" target="_blank">george</a>.
        </div>
    </div>
</footer>
